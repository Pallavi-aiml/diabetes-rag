"""
retrieval/retriever.py
Hybrid retrieval pipeline:
  1. Dense retrieval  — ChromaDB (PubMedBERT cosine similarity)
  2. Sparse retrieval — BM25 (rank-bm25)
  3. Score fusion     — Reciprocal Rank Fusion (RRF)
  4. Reranking        — cross-encoder ms-marco
"""

import os
import sys
from pathlib import Path

from rank_bm25 import BM25Okapi
from sentence_transformers import CrossEncoder
import chromadb

sys.path.append(str(Path(__file__).parent.parent))
from config import (
    CHROMA_DB_PATH, COLLECTION_NAME,
    TOP_K_RETRIEVE, TOP_K_RERANK, RERANKER_MODEL
)
from ingestion.embedder import embed_query, get_chroma_collection


# Load reranker once
print(f"Loading reranker: {RERANKER_MODEL}")
reranker = CrossEncoder(RERANKER_MODEL, max_length=512)


# ---------------------------------------------------------------------------
# Reciprocal Rank Fusion
# ---------------------------------------------------------------------------

def reciprocal_rank_fusion(ranked_lists: list[list[dict]], k: int = 60) -> list[dict]:
    """
    Merge multiple ranked lists of chunk dicts into one via RRF.
    Each dict must have a 'chunk_id' key.
    """
    scores: dict[str, float] = {}
    id_to_doc: dict[str, dict] = {}

    for ranked_list in ranked_lists:
        for rank, doc in enumerate(ranked_list):
            cid = doc["chunk_id"]
            id_to_doc[cid] = doc
            scores[cid] = scores.get(cid, 0.0) + 1.0 / (k + rank + 1)

    sorted_ids = sorted(scores, key=lambda x: scores[x], reverse=True)
    return [id_to_doc[cid] for cid in sorted_ids]


# ---------------------------------------------------------------------------
# Dense retrieval (ChromaDB)
# ---------------------------------------------------------------------------

def dense_retrieve(query: str, collection: chromadb.Collection, n: int = TOP_K_RETRIEVE) -> list[dict]:
    """Return top-n chunks by cosine similarity from ChromaDB."""
    query_vec = embed_query(query).tolist()
    results = collection.query(
        query_embeddings=query_vec,
        n_results=n,
        include=["documents", "metadatas", "distances"],
    )

    docs = []
    for i in range(len(results["documents"][0])):
        meta = results["metadatas"][0][i]
        docs.append({
            "chunk_id": results["ids"][0][i],
            "text": results["documents"][0][i],
            "distance": results["distances"][0][i],
            **meta,
        })
    return docs


# ---------------------------------------------------------------------------
# Sparse retrieval (BM25)
# ---------------------------------------------------------------------------

def build_bm25_index(chunks: list[dict]) -> BM25Okapi:
    """Build a BM25 index from a list of chunk dicts."""
    tokenized = [c["text"].lower().split() for c in chunks]
    return BM25Okapi(tokenized)


def bm25_retrieve(query: str, bm25_index: BM25Okapi,
                  all_chunks: list[dict], n: int = TOP_K_RETRIEVE) -> list[dict]:
    """Return top-n chunks by BM25 score."""
    query_tokens = query.lower().split()
    scores = bm25_index.get_scores(query_tokens)
    top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:n]
    return [all_chunks[i] for i in top_indices]


# ---------------------------------------------------------------------------
# Cross-encoder reranker
# ---------------------------------------------------------------------------

def rerank(query: str, docs: list[dict], top_k: int = TOP_K_RERANK) -> list[dict]:
    """Rerank docs using a cross-encoder model. Returns top_k."""
    if not docs:
        return []
    pairs = [(query, doc["text"][:512]) for doc in docs]
    scores = reranker.predict(pairs)
    ranked = sorted(zip(scores, docs), key=lambda x: x[0], reverse=True)
    reranked = []
    for score, doc in ranked[:top_k]:
        doc["rerank_score"] = float(score)
        reranked.append(doc)
    return reranked


# ---------------------------------------------------------------------------
# Main hybrid retrieval function
# ---------------------------------------------------------------------------

_bm25_cache: dict = {"index": None, "chunks": None}


def hybrid_retrieve(
    query: str,
    collection: chromadb.Collection,
    all_chunks: list[dict],
    top_k: int = TOP_K_RERANK,
) -> list[dict]:
    """
    Full hybrid retrieval pipeline:
      dense → sparse → RRF → rerank → top_k results
    """
    # Build BM25 index (cache it per session)
    global _bm25_cache
    if _bm25_cache["chunks"] is not all_chunks or _bm25_cache["index"] is None:
        print("Building BM25 index…")
        _bm25_cache["index"] = build_bm25_index(all_chunks)
        _bm25_cache["chunks"] = all_chunks

    # Step 1: Dense retrieval
    dense_docs = dense_retrieve(query, collection, n=TOP_K_RETRIEVE)

    # Step 2: Sparse BM25 retrieval
    bm25_docs = bm25_retrieve(query, _bm25_cache["index"], all_chunks, n=TOP_K_RETRIEVE)

    # Step 3: Fuse rankings
    fused = reciprocal_rank_fusion([dense_docs, bm25_docs])

    # Step 4: Rerank top-20 → top_k
    top_fused = fused[:20]
    reranked = rerank(query, top_fused, top_k=top_k)

    return reranked


# ---------------------------------------------------------------------------
# Entry point (quick test)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from ingestion.chunker import load_chunks
    from ingestion.embedder import get_chroma_collection

    chunks = load_chunks()
    collection = get_chroma_collection()

    query = "What is the recommended HbA1c target for type 2 diabetes?"
    print(f"\nQuery: {query}\n")
    results = hybrid_retrieve(query, collection, chunks)

    for i, r in enumerate(results):
        print(f"[{i+1}] {r['source']} | {r['journal']} ({r['year']})")
        print(f"     {r['text'][:200]}…\n")
