"""
ingestion/loader.py
Fetches PubMed abstracts via E-utilities API and parses clinical guideline PDFs.
"""

import os
import json
import time
import xml.etree.ElementTree as ET
from pathlib import Path

import requests
import fitz  # PyMuPDF

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (
    PUBMED_BASE_URL, PUBMED_EMAIL, RAW_DATA_PATH,
    PROCESSED_DATA_PATH, PUBMED_QUERIES
)


# ---------------------------------------------------------------------------
# PubMed helpers
# ---------------------------------------------------------------------------

def search_pubmed_ids(query: str, max_results: int = 500) -> list[str]:
    """Return a list of PubMed IDs matching a query."""
    url = f"{PUBMED_BASE_URL}/esearch.fcgi"
    params = {
        "db": "pubmed",
        "term": query,
        "retmax": max_results,
        "retmode": "json",
        "email": PUBMED_EMAIL,
    }
    resp = requests.get(url, params=params, timeout=30)
    resp.raise_for_status()
    return resp.json()["esearchresult"]["idlist"]


def fetch_pubmed_records(ids: list[str]) -> str:
    """Fetch XML records for a list of PubMed IDs."""
    url = f"{PUBMED_BASE_URL}/efetch.fcgi"
    params = {
        "db": "pubmed",
        "id": ",".join(ids),
        "rettype": "abstract",
        "retmode": "xml",
        "email": PUBMED_EMAIL,
    }
    resp = requests.get(url, params=params, timeout=60)
    resp.raise_for_status()
    return resp.text


def parse_pubmed_xml(xml_text: str) -> list[dict]:
    """Parse PubMed XML and extract structured records."""
    records = []
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return records

    for article in root.findall(".//PubmedArticle"):
        try:
            # PMID
            pmid_el = article.find(".//PMID")
            pmid = pmid_el.text if pmid_el is not None else "unknown"

            # Title
            title_el = article.find(".//ArticleTitle")
            title = title_el.text if title_el is not None else ""

            # Abstract
            abstract_parts = article.findall(".//AbstractText")
            abstract = " ".join(
                (el.text or "") for el in abstract_parts if el.text
            )
            if not abstract:
                continue

            # Journal
            journal_el = article.find(".//Journal/Title")
            journal = journal_el.text if journal_el is not None else "Unknown"

            # Year
            year_el = article.find(".//PubDate/Year")
            year = int(year_el.text) if year_el is not None else 2000

            # Publication type (determine source_type)
            pub_types = [
                pt.text.lower()
                for pt in article.findall(".//PublicationType")
                if pt.text
            ]
            source_type = "unknown"
            if any("randomized" in pt or "clinical trial" in pt for pt in pub_types):
                source_type = "rct"
            elif any("systematic" in pt or "meta-analysis" in pt for pt in pub_types):
                source_type = "systematic_review"
            elif any("review" in pt for pt in pub_types):
                source_type = "cohort_study"
            elif any("case" in pt for pt in pub_types):
                source_type = "case_report"
            else:
                source_type = "expert_opinion"

            records.append({
                "pmid": pmid,
                "text": f"{title}. {abstract}",
                "title": title,
                "source": f"PubMed:{pmid}",
                "journal": journal,
                "year": year,
                "source_type": source_type,
                "page": 0,
            })
        except Exception:
            continue

    return records


def fetch_all_pubmed(queries: list[str] = None, max_per_query: int = 300) -> list[dict]:
    """
    Fetch PubMed abstracts for all configured queries.
    Saves raw XML per query and returns combined list of parsed records.
    """
    if queries is None:
        queries = PUBMED_QUERIES

    os.makedirs(RAW_DATA_PATH, exist_ok=True)
    all_records = []
    seen_pmids = set()

    for i, query in enumerate(queries):
        print(f"[{i+1}/{len(queries)}] Fetching: '{query}'")
        try:
            ids = search_pubmed_ids(query, max_results=max_per_query)
            if not ids:
                print(f"  No results for query.")
                continue

            print(f"  Found {len(ids)} IDs — fetching records...")
            # Fetch in batches of 100
            for batch_start in range(0, len(ids), 100):
                batch = ids[batch_start: batch_start + 100]
                xml_text = fetch_pubmed_records(batch)

                # Save raw XML
                raw_path = Path(RAW_DATA_PATH) / f"pubmed_query_{i:02d}_batch_{batch_start:04d}.xml"
                raw_path.write_text(xml_text, encoding="utf-8")

                records = parse_pubmed_xml(xml_text)
                # Deduplicate by PMID
                for rec in records:
                    if rec["pmid"] not in seen_pmids:
                        seen_pmids.add(rec["pmid"])
                        all_records.append(rec)

                time.sleep(0.5)  # be polite to NCBI

            print(f"  Parsed {len(all_records)} unique records so far.")
        except Exception as e:
            print(f"  Error fetching query: {e}")

    # Save combined processed records
    os.makedirs(PROCESSED_DATA_PATH, exist_ok=True)
    out_path = Path(PROCESSED_DATA_PATH) / "pubmed_records.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(all_records, f, indent=2, ensure_ascii=False)

    print(f"\nTotal unique PubMed records saved: {len(all_records)}")
    return all_records


# ---------------------------------------------------------------------------
# PDF parser (ADA guidelines, ICMR, WHO, etc.)
# ---------------------------------------------------------------------------

def parse_pdf(pdf_path: str, source_type: str = "clinical_guideline",
              journal: str = "Clinical Guideline", year: int = 2024) -> list[dict]:
    """
    Parse a clinical guideline PDF into page-level text records.
    """
    doc = fitz.open(pdf_path)
    pages = []
    pdf_name = Path(pdf_path).stem

    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text("text").strip()
        if len(text) < 50:  # skip blank / cover pages
            continue
        pages.append({
            "text": text,
            "title": pdf_name,
            "source": f"{pdf_name}:page{page_num + 1}",
            "journal": journal,
            "year": year,
            "source_type": source_type,
            "page": page_num + 1,
            "pmid": "N/A",
        })

    doc.close()
    print(f"Parsed {len(pages)} pages from {Path(pdf_path).name}")
    return pages


def load_all_pdfs(pdf_dir: str = None) -> list[dict]:
    """
    Load and parse all PDFs found in the raw data directory.
    Looks for ADA, WHO, ICMR naming conventions to assign metadata.
    """
    if pdf_dir is None:
        pdf_dir = RAW_DATA_PATH

    pdf_path = Path(pdf_dir)
    if not pdf_path.exists():
        print(f"PDF directory not found: {pdf_dir}")
        return []

    pdf_files = list(pdf_path.glob("*.pdf"))
    if not pdf_files:
        print(f"No PDFs found in {pdf_dir}. Place guideline PDFs there.")
        return []

    all_pages = []
    for pdf_file in pdf_files:
        name = pdf_file.stem.lower()
        if "ada" in name:
            journal, year = "Diabetes Care (ADA)", 2024
        elif "who" in name:
            journal, year = "WHO Guideline", 2023
        elif "icmr" in name:
            journal, year = "ICMR Guideline", 2023
        else:
            journal, year = "Clinical Guideline", 2024

        pages = parse_pdf(str(pdf_file), source_type="clinical_guideline",
                          journal=journal, year=year)
        all_pages.extend(pages)

    # Save
    os.makedirs(PROCESSED_DATA_PATH, exist_ok=True)
    out_path = Path(PROCESSED_DATA_PATH) / "pdf_records.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(all_pages, f, indent=2, ensure_ascii=False)

    print(f"Total PDF pages saved: {len(all_pages)}")
    return all_pages


def load_all_documents() -> list[dict]:
    """
    Load all previously processed documents from disk.
    Returns combined list of PubMed + PDF records.
    """
    docs = []
    for fname in ["pubmed_records.json", "pdf_records.json"]:
        fpath = Path(PROCESSED_DATA_PATH) / fname
        if fpath.exists():
            with open(fpath, "r", encoding="utf-8") as f:
                records = json.load(f)
            docs.extend(records)
            print(f"Loaded {len(records)} records from {fname}")
    return docs


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=== Step 1: Fetching PubMed abstracts ===")
    pubmed_records = fetch_all_pubmed()

    print("\n=== Step 2: Parsing guideline PDFs ===")
    pdf_records = load_all_pdfs()

    total = len(pubmed_records) + len(pdf_records)
    print(f"\n=== Ingestion complete. Total documents: {total} ===")
