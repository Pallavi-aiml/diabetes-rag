"""
evidence/verifier.py
Core innovation module — Evidence Verification Layer.

For every retrieved chunk this module computes:
  1. Credibility score     — source type + journal tier + recency
  2. Evidence grade        — GRADE classification (A / B / C / D)
  3. Faithfulness score    — NLI entailment check (bart-large-mnli)
  4. Contradiction flag    — pairwise NLI across retrieved chunks
  5. Confidence aggregate  — weighted combination of all above scores
"""

import os
import sys
from pathlib import Path
from typing import Optional

from transformers import pipeline

sys.path.append(str(Path(__file__).parent.parent))
from config import (
    NLI_MODEL, FAITHFULNESS_THRESHOLD,
    CONTRADICTION_THRESHOLD, SOURCE_SCORES, JOURNAL_SCORES,
)

# ---------------------------------------------------------------------------
# Load NLI model once at module level
# ---------------------------------------------------------------------------
print(f"Loading NLI model: {NLI_MODEL}")
nli_pipeline = pipeline(
    "zero-shot-classification",
    model=NLI_MODEL,
    device=-1,          # CPU; set to 0 for GPU
)


# ---------------------------------------------------------------------------
# 1. Credibility Scoring
# ---------------------------------------------------------------------------

def score_credibility(chunk: dict) -> float:
    """
    Compute a credibility score 0–5 for a chunk based on:
      - Source type  (RCT, systematic review, guideline, etc.)
      - Journal tier (Diabetes Care, Lancet, etc.)
      - Publication recency
    """
    source_type = chunk.get("source_type", "unknown").lower()
    journal     = chunk.get("journal", "Unknown")
    year        = int(chunk.get("year", 2000))

    # Source type score (0–5)
    src_score = SOURCE_SCORES.get(source_type, 0)

    # Journal tier score (0–5)
    jnl_score = JOURNAL_SCORES.get(journal, 2)

    # Recency score (0–5): papers from 2020+ get full marks
    recency = min(5.0, max(0.0, (year - 2010) * 0.5))

    # Weighted combination
    credibility = round(
        src_score  * 0.50 +
        jnl_score  * 0.30 +
        recency    * 0.20,
        3,
    )
    return min(5.0, credibility)


# ---------------------------------------------------------------------------
# 2. GRADE Evidence Classification
# ---------------------------------------------------------------------------

GRADE_KEYWORDS = {
    "A": [
        "randomized controlled trial", "rct", "meta-analysis",
        "systematic review", "randomised", "double-blind",
    ],
    "B": [
        "cohort study", "prospective", "retrospective", "guideline",
        "clinical practice", "standards of care", "recommendation",
        "controlled study", "observational",
    ],
    "C": [
        "case-control", "cross-sectional", "pilot study",
        "small sample", "case series",
    ],
    "D": [
        "case report", "expert opinion", "editorial", "letter",
        "anecdotal", "in vitro", "animal study",
    ],
}


def classify_evidence_grade(chunk: dict) -> str:
    """
    Assign GRADE level A/B/C/D based on:
      - source_type metadata
      - keyword signals in the chunk text
    Returns the highest (best) grade found.
    """
    text        = chunk.get("text", "").lower()
    source_type = chunk.get("source_type", "").lower()

    # Source-type fast path
    if source_type in ("systematic_review", "rct"):
        return "A"
    if source_type in ("clinical_guideline",):
        return "B"
    if source_type in ("cohort_study",):
        return "B"
    if source_type in ("case_report",):
        return "C"

    # Keyword scan (highest grade wins)
    for grade in ("A", "B", "C", "D"):
        for kw in GRADE_KEYWORDS[grade]:
            if kw in text:
                return grade

    return "D"


# ---------------------------------------------------------------------------
# 3. Faithfulness / Hallucination Detection (NLI)
# ---------------------------------------------------------------------------




def check_faithfulness(generated_answer: str, context_chunk: str) -> float:
    premise    = context_chunk[:512]
    hypothesis = generated_answer[:256]
    try:
        result = nli_pipeline(
            sequences=premise,
            candidate_labels=["supported", "unrelated", "contradicted"],
        )
        label_scores = dict(zip(result["labels"], result["scores"]))
        return round(label_scores.get("supported", 0.0), 4)
    except Exception:
        return 0.5

def check_faithfulness_multi(generated_answer: str, chunks: list) -> float:
    if not chunks:
        return 0.0
    top3 = chunks[:3]
    scores = [check_faithfulness(generated_answer, c["text"]) for c in top3]
    return round(sum(scores) / len(scores), 4)

# ---------------------------------------------------------------------------
# 4. Contradiction Detection
# ---------------------------------------------------------------------------


def detect_contradiction(chunk_a: str, chunk_b: str) -> bool:
    combined = chunk_a[:400] + " [SEP] " + chunk_b[:400]
    result = nli_pipeline(
        combined[:512],
        candidate_labels=["entailment", "neutral", "contradiction"],
    )
    label_scores = dict(zip(result["labels"], result["scores"]))
    return label_scores.get("contradiction", 0.0) > CONTRADICTION_THRESHOLD


def find_contradictions(chunks: list[dict]) -> list[tuple[int, int]]:
    """
    Pairwise contradiction scan across all retrieved chunks.
    Returns list of (i, j) index pairs that contradict each other.
    """
    contradictions = []
    for i in range(len(chunks)):
        for j in range(i + 1, len(chunks)):
            if detect_contradiction(chunks[i]["text"], chunks[j]["text"]):
                contradictions.append((i, j))
    return contradictions


# ---------------------------------------------------------------------------
# 5. Verify chunks (adds all metadata in-place)
# ---------------------------------------------------------------------------

def verify_chunks(chunks: list[dict]) -> list[dict]:
    """
    Annotate every chunk with credibility score and evidence grade.
    (Faithfulness requires the generated answer, so it's done separately.)
    """
    for chunk in chunks:
        chunk["credibility_score"] = score_credibility(chunk)
        chunk["evidence_grade"]    = classify_evidence_grade(chunk)
    return chunks


# ---------------------------------------------------------------------------
# 6. Confidence Aggregator
# ---------------------------------------------------------------------------

def aggregate_confidence(
    verified_chunks: list[dict],
    generated_answer: str,
) -> dict:
    """
    Compute a final confidence report for a generated answer.

    Returns:
        {
          "confidence":      float  [0-1],
          "grade":           str    best evidence grade across chunks,
          "faithfulness":    float  NLI entailment against top chunks,
          "avg_credibility": float  mean credibility score,
          "contradictions":  list   pairs of contradicting chunk indices,
          "hallucination_risk": bool  True if faithfulness < threshold,
        }
    """
    if not verified_chunks:
        return {
            "confidence": 0.0, "grade": "D",
            "faithfulness": 0.0, "avg_credibility": 0.0,
            "contradictions": [], "hallucination_risk": True,
        }

    # Faithfulness
    faithfulness = check_faithfulness_multi(generated_answer, verified_chunks)

    # Average credibility
    avg_cred = sum(c.get("credibility_score", 0) for c in verified_chunks) / len(verified_chunks)

    # Best evidence grade
    grade_order = {"A": 4, "B": 3, "C": 2, "D": 1}
    best_grade = max(
        verified_chunks,
        key=lambda c: grade_order.get(c.get("evidence_grade", "D"), 0),
    )["evidence_grade"]

    # Contradiction check
    contradictions = find_contradictions(verified_chunks)

    # Confidence score: faithfulness 50% + normalised credibility 40% + grade bonus 10%
    grade_bonus = {"A": 0.10, "B": 0.07, "C": 0.04, "D": 0.0}.get(best_grade, 0.0)
    confidence = round(
        faithfulness       * 0.50 +
        (avg_cred / 5.0)   * 0.40 +
        grade_bonus,
        4,
    )
    confidence = min(1.0, max(0.0, confidence))

    # Penalise if contradictions found
    if contradictions:
        confidence = round(confidence * 0.85, 4)

    hallucination_risk = faithfulness < FAITHFULNESS_THRESHOLD

    return {
        "confidence":       confidence,
        "grade":            best_grade,
        "faithfulness":     faithfulness,
        "avg_credibility":  round(avg_cred, 3),
        "contradictions":   contradictions,
        "hallucination_risk": hallucination_risk,
    }


# ---------------------------------------------------------------------------
# Entry point (quick smoke test)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    sample_chunks = [
        {
            "chunk_id": "test_001",
            "text": (
                "A randomized controlled trial showed that metformin reduces HbA1c "
                "by approximately 1.5% in patients with type 2 diabetes mellitus."
            ),
            "source": "PubMed:12345",
            "journal": "Diabetes Care",
            "year": 2023,
            "source_type": "rct",
        },
        {
            "chunk_id": "test_002",
            "text": (
                "The ADA Standards of Medical Care recommend an HbA1c target of "
                "less than 7% for most non-pregnant adults with diabetes."
            ),
            "source": "ADA_Guidelines:page12",
            "journal": "Diabetes Care (ADA)",
            "year": 2024,
            "source_type": "clinical_guideline",
        },
    ]

    print("=== Verifying chunks ===")
    verified = verify_chunks(sample_chunks)
    for c in verified:
        print(f"  [{c['chunk_id']}] grade={c['evidence_grade']}  cred={c['credibility_score']}")

    generated = "The recommended HbA1c target is less than 7% and metformin is first-line therapy."
    print("\n=== Aggregating confidence ===")
    report = aggregate_confidence(verified, generated)
    for k, v in report.items():
        print(f"  {k}: {v}")
